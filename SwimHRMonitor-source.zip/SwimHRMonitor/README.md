# Swim HR Monitor — Android prototype 0.1.0

这是一个原生 Android BLE 心率接收原型，目标设备为 Xiaomi Smart Band 10 的标准 Bluetooth Heart Rate 广播。

## 当前实现
- Android 10+（minSdk 29），横屏、保持屏幕常亮
- 扫描标准 BLE Heart Rate Service（UUID 0x180D）
- 发现后自动尝试 GATT 连接并订阅 Heart Rate Measurement（0x2A37）
- 多设备卡片、实时 BPM、设备连接状态、最高心率
- 长按卡片可修改运动员姓名
- 简单训练计时器
- 本地运行，不需要账号或网络

## 重要限制
- 这是 0.1.0 原型，不是已经在真实设备上验证过的正式版。
- 需要手环端打开：设置 > 分享心率（Share HR）。
- 手机/平板必须打开蓝牙并授予应用蓝牙权限。
- 目前扫描逻辑依赖广播包公开 0x180D 服务 UUID；若手环固件采用不同广播方式，需要调整发现逻辑。
- 多设备并发数量受安卓设备蓝牙芯片、系统栈和手环固件限制，代码没有承诺一定稳定支持 20 台。
- 水下 2.4GHz 蓝牙传输会严重衰减；此应用不能保证运动员完全浸水时岸上持续收到心率。
- 当前版本尚未实现训练历史持久化、CSV 导出、前台服务后台保活和自动重连策略。

## 用 Android Studio 构建 APK
1. 安装 Android Studio（建议最新版）和 Android SDK Platform 35。
2. 解压项目，Android Studio 选择 Open，打开 `SwimHRMonitor` 文件夹。
3. 等待 Gradle Sync 完成。
4. 连接 Android 手机/平板，或选择 Build > Build Bundle(s) / APK(s) > Build APK(s)。
5. APK 通常位于 `app/build/outputs/apk/debug/app-debug.apk`。

## 第一次测试
1. 手环先与 Mi Fitness 正常配对。
2. 手环上打开 设置 > 分享心率（Share HR）。
3. 打开本应用，授予蓝牙权限。
4. 点击“扫描 / 连接手环”。
5. 如果发现后显示已连接但 BPM 仍为 `--`，请提供手环固件版本、扫描日志和安卓设备型号，以便排查 CCCD 通知订阅兼容性。
