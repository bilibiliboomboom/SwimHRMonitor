package com.swimhr.monitor;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelUuid;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final UUID HR_SERVICE = UUID.fromString("0000180d-0000-1000-8000-00805f9b34fb");
    private static final UUID HR_MEASUREMENT = UUID.fromString("00002a37-0000-1000-8000-00805f9b34fb");
    private static final UUID CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
    private static final ParcelUuid HR_PARCEL = new ParcelUuid(HR_SERVICE);

    private BluetoothAdapter adapter;
    private BluetoothLeScanner scanner;
    private boolean scanning = false;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Map<String, Athlete> athletes = new HashMap<>();
    private final Map<String, BluetoothGatt> gatts = new HashMap<>();
    private final Map<String, TextView> cardViews = new HashMap<>();
    private LinearLayout root, header, cards;
    private TextView status, timerView;
    private long trainingStart = 0;
    private boolean training = false;
    private final Runnable timerRunnable = new Runnable() {
        @Override public void run() {
            if (training) {
                long s = (System.currentTimeMillis() - trainingStart) / 1000;
                timerView.setText(String.format(Locale.getDefault(), "训练 %02d:%02d:%02d", s/3600, (s%3600)/60, s%60));
                handler.postDelayed(this, 1000);
            }
        }
    };

    static class Athlete {
        String address, name;
        int bpm = -1, max = -1, samples = 0;
        long lastSeen = 0;
        boolean connected = false;
        Athlete(String a, String n) { address=a; name=n; }
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_KEEP_SCREEN_ON);
        BluetoothManager bm = (BluetoothManager)getSystemService(Context.BLUETOOTH_SERVICE);
        adapter = bm.getAdapter();
        buildUi();
        requestBlePermissions();
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(18, 14, 18, 14);
        root.setBackgroundColor(Color.rgb(12, 18, 30));
        setContentView(root);

        header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(header, new LinearLayout.LayoutParams(-1, 58));

        TextView title = new TextView(this);
        title.setText("SWIM HR  /  泳队实时心率");
        title.setTextColor(Color.WHITE); title.setTextSize(22); title.setTypeface(null, 1);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1));

        timerView = new TextView(this);
        timerView.setText("训练 00:00:00"); timerView.setTextColor(Color.LTGRAY); timerView.setTextSize(16);
        header.addView(timerView);

        Button train = button("开始训练");
        header.addView(train);
        train.setOnClickListener(v -> {
            if (!training) {
                training = true; trainingStart = System.currentTimeMillis();
                train.setText("结束训练"); handler.post(timerRunnable);
            } else {
                training = false; handler.removeCallbacks(timerRunnable);
                train.setText("开始训练");
                Toast.makeText(this, "本次训练结束（当前版本尚未保存训练报告）", Toast.LENGTH_LONG).show();
            }
        });

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(bar, new LinearLayout.LayoutParams(-1, 54));
        Button scan = button("扫描 / 连接手环");
        bar.addView(scan);
        scan.setOnClickListener(v -> startScan());
        Button clear = button("清空设备");
        bar.addView(clear);
        clear.setOnClickListener(v -> {
            stopScan();
            for (BluetoothGatt g : new ArrayList<>(gatts.values())) {
                try { g.disconnect(); g.close(); } catch (Exception ignored) {}
            }
            gatts.clear(); athletes.clear(); cardViews.clear(); renderCards();
            status.setText("已清空。请重新扫描。");
        });
        status = new TextView(this);
        status.setText("准备就绪：请先在小米手环10上开启 设置 > 分享心率");
        status.setTextColor(Color.rgb(160, 190, 220)); status.setTextSize(13);
        bar.addView(status, new LinearLayout.LayoutParams(0, -2, 1));

        ScrollView scroll = new ScrollView(this);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        cards = new LinearLayout(this);
        cards.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(cards);
        renderCards();
    }

    private Button button(String t) {
        Button b = new Button(this); b.setText(t); b.setAllCaps(false); return b;
    }

    private void requestBlePermissions() {
        ArrayList<String> p = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 31) {
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) p.add(Manifest.permission.BLUETOOTH_SCAN);
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) p.add(Manifest.permission.BLUETOOTH_CONNECT);
        } else if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            p.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            p.add(Manifest.permission.POST_NOTIFICATIONS);
        if (!p.isEmpty()) requestPermissions(p.toArray(new String[0]), 40);
    }

    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) {
        super.onRequestPermissionsResult(r,p,g);
        if (r == 40) status.setText("权限结果已返回。若扫描失败，请在系统设置中允许蓝牙权限。");
    }

    private boolean hasBlePermission() {
        if (Build.VERSION.SDK_INT >= 31)
            return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
                   checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void startScan() {
        if (adapter == null || !adapter.isEnabled()) {
            Toast.makeText(this, "请先打开蓝牙", Toast.LENGTH_LONG).show(); return;
        }
        if (!hasBlePermission()) { requestBlePermissions(); return; }
        scanner = adapter.getBluetoothLeScanner();
        if (scanner == null) { status.setText("无法取得 BLE 扫描器"); return; }
        if (scanning) stopScan();
        try {
            ScanSettings settings = new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build();
            scanner.startScan(null, settings, scanCallback);
            scanning = true;
            status.setText("正在扫描心率广播设备（0x180D）… 请确保手环已开启分享心率");
            handler.postDelayed(() -> {
                if (scanning) {
                    stopScan();
                    status.setText("扫描结束。已发现 " + athletes.size() + " 台设备；未发现时请检查手环广播开关。");
                }
            }, 15000);
        } catch (SecurityException e) { status.setText("缺少蓝牙权限：" + e.getMessage()); }
    }

    private void stopScan() {
        if (scanner != null && scanning && hasBlePermission()) {
            try { scanner.stopScan(scanCallback); } catch (Exception ignored) {}
        }
        scanning = false;
    }

    private final ScanCallback scanCallback = new ScanCallback() {
        @Override public void onScanResult(int callbackType, ScanResult result) {
            if (result == null || result.getScanRecord() == null) return;
            if (result.getScanRecord().getServiceUuids() == null ||
                !result.getScanRecord().getServiceUuids().contains(HR_PARCEL)) return;
            BluetoothDevice d = result.getDevice();
            String address = d.getAddress();
            if (athletes.containsKey(address) || gatts.containsKey(address)) return;
            String foundName = result.getScanRecord().getDeviceName();
            if (foundName == null || foundName.trim().isEmpty()) foundName = "运动员 " + (athletes.size()+1);
            final String displayName = foundName;
            Athlete a = new Athlete(address, displayName);
            athletes.put(address, a);
            runOnUiThread(() -> { renderCards(); status.setText("发现 " + displayName + "，正在连接…"); });
            connect(d, address);
        }
        @Override public void onScanFailed(int errorCode) {
            runOnUiThread(() -> status.setText("蓝牙扫描失败，错误码 " + errorCode));
        }
    };

    private void connect(BluetoothDevice device, String address) {
        if (!hasBlePermission()) return;
        try {
            BluetoothGatt g = device.connectGatt(this, false, new BluetoothGattCallback() {
                @Override public void onConnectionStateChange(BluetoothGatt gatt, int statusCode, int newState) {
                    runOnUiThread(() -> {
                        Athlete a = athletes.get(address);
                        if (a == null) return;
                        a.connected = newState == BluetoothGatt.STATE_CONNECTED && statusCode == BluetoothGatt.GATT_SUCCESS;
                        if (a.connected) {
                            status.setText(a.name + " 已连接，正在发现服务…");
                            if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) return;
                            gatt.discoverServices();
                        } else {
                            status.setText(a.name + " 连接断开");
                            a.lastSeen = 0;
                            updateCard(address);
                            if (statusCode != BluetoothGatt.GATT_SUCCESS) {
                                try { gatt.close(); } catch (Exception ignored) {}
                                gatts.remove(address);
                            }
                        }
                        updateCard(address);
                    });
                }
                @Override public void onServicesDiscovered(BluetoothGatt gatt, int statusCode) {
                    if (statusCode != BluetoothGatt.GATT_SUCCESS) return;
                    BluetoothGattService service = gatt.getService(HR_SERVICE);
                    if (service == null) {
                        runOnUiThread(() -> status.setText("设备未提供标准心率服务： " + address));
                        return;
                    }
                    BluetoothGattCharacteristic c = service.getCharacteristic(HR_MEASUREMENT);
                    if (c == null) return;
                    try {
                        gatt.setCharacteristicNotification(c, true);
                        BluetoothGattDescriptor desc = c.getDescriptor(CCCD);
                        if (desc != null) {
                            if (Build.VERSION.SDK_INT >= 33) gatt.writeDescriptor(desc, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                            else { desc.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE); gatt.writeDescriptor(desc); }
                        }
                    } catch (SecurityException ignored) {}
                }
                @Override public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
                    if (HR_MEASUREMENT.equals(characteristic.getUuid())) {
                        byte[] data = characteristic.getValue();
                        if (data != null && data.length >= 2) {
                            int flags = data[0] & 0xff;
                            int bpm = (flags & 0x01) != 0 && data.length >= 3 ?
                                    ((data[1] & 0xff) | ((data[2] & 0xff) << 8)) : (data[1] & 0xff);
                            runOnUiThread(() -> updateHeartRate(address, bpm));
                        }
                    }
                }
                @Override public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, byte[] value) {
                    if (HR_MEASUREMENT.equals(characteristic.getUuid()) && value != null && value.length >= 2) {
                        int flags = value[0] & 0xff;
                        int bpm = (flags & 0x01) != 0 && value.length >= 3 ?
                                ((value[1] & 0xff) | ((value[2] & 0xff) << 8)) : (value[1] & 0xff);
                        runOnUiThread(() -> updateHeartRate(address, bpm));
                    }
                }
            }, BluetoothDevice.TRANSPORT_LE);
            gatts.put(address, g);
        } catch (SecurityException e) {
            runOnUiThread(() -> status.setText("连接权限不足"));
        }
    }

    private void updateHeartRate(String address, int bpm) {
        Athlete a = athletes.get(address);
        if (a == null) return;
        a.bpm = bpm; a.lastSeen = System.currentTimeMillis(); a.samples++;
        a.max = Math.max(a.max, bpm);
        updateCard(address);
    }

    private void renderCards() {
        cards.removeAllViews();
        for (Athlete a : athletes.values()) {
            TextView tv = makeCard(a);
            cardViews.put(a.address, tv);
            cards.addView(tv);
        }
        if (athletes.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("尚未连接运动员\n点击「扫描 / 连接手环」开始搜索");
            empty.setTextColor(Color.LTGRAY); empty.setTextSize(20); empty.setGravity(Gravity.CENTER);
            empty.setPadding(20, 80, 20, 80); cards.addView(empty);
        }
    }

    private TextView makeCard(Athlete a) {
        TextView tv = new TextView(this);
        tv.setPadding(24, 18, 24, 18);
        tv.setTextSize(18); tv.setTextColor(Color.WHITE);
        tv.setBackgroundColor(Color.rgb(32, 43, 62));
        tv.setOnLongClickListener(v -> { rename(a); return true; });
        formatCard(tv, a);
        return tv;
    }

    private void formatCard(TextView tv, Athlete a) {
        String hr = a.bpm < 0 ? "--" : String.valueOf(a.bpm);
        String conn = a.bpm >= 0 && System.currentTimeMillis()-a.lastSeen > 8000 ? "数据超时" :
                      (a.connected ? "已连接" : "未连接");
        String detail = a.bpm < 0 ? "等待心率数据" : "最高 " + a.max + " BPM";
        tv.setText(a.name + "    " + hr + " BPM\n" + conn + "    " + detail + "\n长按卡片可修改姓名");
        if (a.bpm < 0) tv.setBackgroundColor(Color.rgb(55, 65, 81));
        else if (a.bpm >= 180) tv.setBackgroundColor(Color.rgb(150, 35, 40));
        else if (a.bpm >= 160) tv.setBackgroundColor(Color.rgb(150, 105, 25));
        else tv.setBackgroundColor(Color.rgb(28, 105, 75));
    }

    private void updateCard(String address) {
        TextView tv = cardViews.get(address);
        Athlete a = athletes.get(address);
        if (tv != null && a != null) formatCard(tv, a);
    }

    private void rename(Athlete a) {
        EditText input = new EditText(this);
        input.setSingleLine(true); input.setText(a.name);
        new AlertDialog.Builder(this).setTitle("修改运动员姓名")
                .setView(input).setNegativeButton("取消", null)
                .setPositiveButton("保存", (d,w) -> {
                    a.name = input.getText().toString().trim();
                    if (a.name.isEmpty()) a.name = "运动员";
                    updateCard(a.address);
                }).show();
    }

    @Override protected void onDestroy() {
        stopScan();
        for (BluetoothGatt g : new ArrayList<>(gatts.values())) {
            try { g.disconnect(); g.close(); } catch (Exception ignored) {}
        }
        gatts.clear();
        super.onDestroy();
    }
}
